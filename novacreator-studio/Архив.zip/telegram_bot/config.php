<?php
/**
 * Конфигурация Telegram бота
 * 
 * ИНСТРУКЦИЯ ПО НАСТРОЙКЕ:
 * 1. Создайте бота через @BotFather в Telegram
 * 2. Получите токен бота (например: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz)
 * 3. Узнайте ваш Chat ID (можно через @userinfobot или @getidsbot)
 * 4. Вставьте токен и Chat ID ниже
 */

// Токен вашего Telegram бота (получите у @BotFather)
define('TELEGRAM_BOT_TOKEN', '8581188166:AAH2MQ-RYJO2dCOooehOhj_jbLKm7wnkKQo');

// Chat ID, куда будут приходить сообщения (ваш ID или ID группы)
define('TELEGRAM_CHAT_ID', '-5036819424');

// Включить/выключить отправку в Telegram (true/false)
define('TELEGRAM_ENABLED', true);

?>

