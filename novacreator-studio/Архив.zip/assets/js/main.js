/**
 * Основной JavaScript файл для NovaCreator Studio
 * Содержит анимации, интерактивность и обработку форм
 */

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    initAnimations();
    initNavigation();
    initForms();
    initScrollEffects();
    initCounters();
});

/**
 * Инициализация анимаций при скролле
 * Элементы появляются плавно при прокрутке страницы
 * Оптимизировано для мобильных устройств
 */
function initAnimations() {
    // Проверяем, поддерживает ли устройство анимации (для экономии ресурсов на слабых устройствах)
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    // Создаем Intersection Observer для отслеживания видимости элементов
    // На мобильных используем более агрессивные настройки для производительности
    const isMobile = window.innerWidth < 768;
    const observerOptions = {
        threshold: isMobile ? 0.05 : 0.1, // На мобильных срабатывает раньше
        rootMargin: isMobile ? '0px 0px -30px 0px' : '0px 0px -50px 0px' // Меньший отступ на мобильных
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Добавляем класс для анимации
                entry.target.classList.add('animate-fade-in');
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                // Отключаем наблюдение после анимации
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Находим все элементы с классом для анимации
    const animatedElements = document.querySelectorAll('.animate-on-scroll');
    
    animatedElements.forEach(element => {
        // Пропускаем анимацию, если пользователь предпочитает уменьшенное движение
        if (prefersReducedMotion) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
            return;
        }
        
        // Устанавливаем начальное состояние
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        // На мобильных используем более короткую анимацию для лучшей производительности
        const duration = isMobile ? '0.4s' : '0.6s';
        element.style.transition = `opacity ${duration} ease-out, transform ${duration} ease-out`;
        
        // Начинаем наблюдение
        observer.observe(element);
    });
}

/**
 * Инициализация навигации
 * Плавная прокрутка к якорям и активное состояние меню
 */
function initNavigation() {
    // Обработка кликов по ссылкам с якорями
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Пропускаем пустые якоря
            if (href === '#') return;
            
            e.preventDefault();
            
            const target = document.querySelector(href);
            if (target) {
                // Плавная прокрутка к элементу
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Изменение стиля навигации при скролле
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }
}

/**
 * Инициализация обработки форм
 * Отправка данных через fetch API на backend
 */
function initForms() {
    const forms = document.querySelectorAll('.contact-form');
    
    forms.forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault(); // Предотвращаем стандартную отправку формы
            
            // Получаем кнопку отправки
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            // Показываем состояние загрузки
            submitBtn.disabled = true;
            submitBtn.textContent = 'Отправка...';
            
            // Собираем данные формы
            const formData = new FormData(form);
            
            try {
                // Отправляем запрос на сервер
                // Используем относительный путь для корректной работы на всех страницах
                const formAction = form.getAttribute('action') || './backend/send.php';
                const response = await fetch(formAction, {
                    method: 'POST',
                    body: formData
                });
                
                // Парсим JSON ответ
                const result = await response.json();
                
                if (result.success) {
                    // Успешная отправка
                    showNotification('Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в ближайшее время.', 'success');
                    form.reset(); // Очищаем форму
                } else {
                    // Ошибка на сервере
                    showNotification(result.message || 'Произошла ошибка при отправке. Попробуйте позже.', 'error');
                }
            } catch (error) {
                // Ошибка сети или другая ошибка
                console.error('Ошибка отправки формы:', error);
                showNotification('Ошибка соединения. Проверьте интернет и попробуйте снова.', 'error');
            } finally {
                // Восстанавливаем кнопку
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    });
}

/**
 * Показ уведомления пользователю
 * Оптимизировано для мобильных устройств
 * @param {string} message - Текст уведомления
 * @param {string} type - Тип: 'success' или 'error'
 */
function showNotification(message, type = 'success') {
    // Определяем позицию для мобильных и десктопа
    const isMobile = window.innerWidth < 768;
    const positionClass = isMobile 
        ? 'top-4 left-4 right-4' // На мобильных занимает всю ширину
        : 'top-4 right-4'; // На десктопе справа
    
    // Создаем элемент уведомления
    const notification = document.createElement('div');
    notification.className = `fixed ${positionClass} z-50 px-4 py-3 md:px-6 md:py-4 rounded-lg shadow-lg transform transition-all duration-300 text-sm md:text-base ${
        type === 'success' 
            ? 'bg-green-600 text-white' 
            : 'bg-red-600 text-white'
    }`;
    notification.textContent = message;
    
    // Добавляем на страницу
    document.body.appendChild(notification);
    
    // Анимация появления
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Удаляем через 5 секунд
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 5000);
}

/**
 * Дополнительные эффекты при скролле
 * Параллакс эффекты и другие визуальные улучшения
 */
function initScrollEffects() {
    // Эффект параллакса для фоновых элементов
    const parallaxElements = document.querySelectorAll('.parallax');
    
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        
        parallaxElements.forEach(element => {
            const speed = element.dataset.speed || 0.5;
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
    
    // Подсветка активного раздела в навигации
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    window.addEventListener('scroll', function() {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (window.pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

/**
 * Плавное появление чисел (для статистики)
 * Анимация счетчика от 0 до целевого значения
 * @param {HTMLElement} element - Элемент для анимации
 * @param {number} target - Целевое значение
 * @param {string} prefix - Префикс (например, "+" или "-")
 * @param {string} suffix - Суффикс (например, "%")
 * @param {number} duration - Длительность анимации в миллисекундах
 */
function animateCounter(element, target, prefix = '', suffix = '', duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16); // 60 FPS для плавной анимации
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = prefix + target + suffix;
            clearInterval(timer);
        } else {
            element.textContent = prefix + Math.floor(start) + suffix;
        }
    }, 16);
}

/**
 * Инициализация счетчиков на странице
 * Анимация запускается, когда элемент появляется в viewport
 */
function initCounters() {
    const counterElements = document.querySelectorAll('.counter-number');
    
    if (counterElements.length === 0) return;
    
    // Создаем Intersection Observer для отслеживания видимости
    const observerOptions = {
        threshold: 0.5, // Запускаем анимацию, когда элемент виден на 50%
        rootMargin: '0px'
    };
    
    const counterObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const element = entry.target;
                const target = parseInt(element.getAttribute('data-target')) || 0;
                const prefix = element.getAttribute('data-prefix') || '';
                const suffix = element.getAttribute('data-suffix') || '';
                const duration = parseInt(element.getAttribute('data-duration')) || 2000;
                
                // Проверяем, не была ли уже запущена анимация
                if (!element.classList.contains('counter-animated')) {
                    element.classList.add('counter-animated');
                    animateCounter(element, target, prefix, suffix, duration);
                }
                
                // Отключаем наблюдение после запуска анимации
                counterObserver.unobserve(element);
            }
        });
    }, observerOptions);
    
    // Начинаем наблюдение за каждым счетчиком
    counterElements.forEach(element => {
        counterObserver.observe(element);
    });
}

// Экспортируем функции для использования в других скриптах
window.NovaCreator = {
    animateCounter,
    showNotification,
    initCounters
};

